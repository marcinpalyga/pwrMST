import time
print(time.mktime(time.localtime()))